#ifndef _ITEM1_H
#define _ITEM1_H

#include "Item.h"
#include <cstring>

class Item1 : public Item
{
public:
  Item1(int l, int c);
};

#endif
