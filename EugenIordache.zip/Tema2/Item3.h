#ifndef _ITEM3_H
#define _ITEM3_H

#include "Item.h"
#include <cstring>

class Item3 : public Item
{
public:
  Item3(int l, int c);
};

#endif
