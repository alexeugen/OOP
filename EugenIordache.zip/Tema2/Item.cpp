#include "Item.h"

int Item::GetLin()
{
  return _lin;
}
int Item::GetCol()
{
  return _col;
}
char Item::GetSymbol()
{
  return _symbol;
}
char* Item::GetType()
{
  return _type;
}
