#ifndef _ITEM2_H
#define _ITEM2_H

#include "Item.h"
#include <cstring>

class Item2 : public Item
{
public:
  Item2(int l, int c);
};

#endif
